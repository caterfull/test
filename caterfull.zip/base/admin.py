from django.contrib import admin

# Register your models here.
from base.model_invoice import N_Proposal_Status, N_Invoice_Status, Event, Proposal, Item, Invoice

from base.models import Business, Customer, N_Company, N_Suffix, \
    N_Prefix, ConfirmEmailOrder, N_NotificationType, Notification, Oferta

admin.site.register(Business)
admin.site.register(Customer)



admin.site.register(N_Company)
admin.site.register(N_Suffix)
admin.site.register(N_Prefix)

admin.site.register(ConfirmEmailOrder)

admin.site.register(N_NotificationType)
admin.site.register(Notification)
admin.site.register(N_Proposal_Status)
admin.site.register(N_Invoice_Status)
admin.site.register(Event)
admin.site.register(Proposal)
admin.site.register(Oferta)
admin.site.register(Item)
admin.site.register(Invoice)
